# netflix-clone-react

## Aula 01:
Nesta aula refatoramos um projeto que estava em `HTML` e `CSS` para um projeto `React` sem componentes. 
Toda a estrutura do projeto anterior foi passado para dentro do componente App.js e alterado a sintáxe do html para se tornar um JSX.

